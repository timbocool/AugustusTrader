//using Microsoft.EntityFrameworkCore;
//using System.Collections.Generic;
//using System.Reflection.Emit;

//namespace RecoMakerBot
//{
//    public class ApplicationDbContext : DbContext
//    {
//        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
//            : base(options)
//        {
//        }

//        // Map the MarketData table
//        public DbSet<MarketData> MarketData { get; set; } = null!;
//        public DbSet<Candles> Candles { get; set; } = null!;
//        public DbSet<RecoLog> RecoLog { get; set; }

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {

//        }
//    }


//}
